from django.urls import path
from . import views

app_name = 'polls'

urlpatterns = [
    path('wash/', views.wash, name = 'wash'),
    path('wash/customer/', views.customer, name = 'customer'),
    path('message/', views.message, name = 'message'),
    path('manage/', views.manage, name ='manage')
    #path('<int:last_number>/', views.number, name='number'),
    #path('<int:last_number>/results/', views.check, name='check'), #전화번호 뒷4자리 조회
    #path('new_customer/', views.addcustomer, name='addcustomer'),
]