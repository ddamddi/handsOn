from django.contrib import admin
from polls.models import Customer, Order, SubOrder, Service, Clothes
# Register your models here.

admin.site.register(Customer)
admin.site.register(Order)
admin.site.register(SubOrder)
admin.site.register(Service)
admin.site.register(Clothes)