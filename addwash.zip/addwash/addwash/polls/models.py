from django.db import models
# Create your models here.

class Customer(models.Model):
    # 전화번호 분할 010-1234-5678
    first_number = models.IntegerField(default=0)    # 010
    second_number = models.IntegerField(default=0)   # 1234
    last_number = models.IntegerField(default=0)     # 5678
    number = models.IntegerField(default=0)   # 12345678
    name = models.CharField(max_length=10)
    address = models.CharField(max_length= 100)
    message_agree = models.BooleanField()
    Wash_id = models.IntegerField(default=0)

    def __str__(self):
        return self.name

class Order(models.Model):
    order_number = models.IntegerField(default=0)
    phone_number = models.ForeignKey(Customer, on_delete=models.CASCADE)
    count = models.IntegerField(default=0)

    def __str__(self):
        return self.order_number

class Clothes(models.Model):
    clothes_code = models.IntegerField(default=0)
    clothes_name = models.CharField(max_length=20)

    def __str__(self):
        return self.clothes_name

class Service(models.Model):
    service_code = models.IntegerField(default=0)
    service_name = models.CharField(max_length=20)    
    
    def __str__(self):
        return self.service_name

class SubOrder(models.Model):
    sub_number = models.IntegerField(default=0)
    order_number = models.ForeignKey(Order, on_delete=models.CASCADE)
    service_code = models.ForeignKey(Service, on_delete=models.CASCADE)
    clothes_code = models.ForeignKey(Clothes, on_delete=models.CASCADE)
    status = models.IntegerField(default=0)
    price = models.IntegerField(default=0)
    checkin_date = models.IntegerField(default=0)
    deadline_date = models.IntegerField(default=0)
    finish_datd = models.IntegerField(default=0)
    checkout_date = models.IntegerField(default=0)
    payment = models.BooleanField()
    review = models.CharField(max_length=100)

    def __str__(self):
        return self.status
