from django.shortcuts import render, get_object_or_404
from django.views.generic import TemplateView
from django.conf import settings
from . import views
from . import models

# Create your views here.

class WashView(TemplateView):
    template_name="polls/wash.html"
    redirect_authenticated_user = True
    
    def add_customer(self, request, *args, **kwargs):
        return render(request, 'polls/customer.html')

wash = WashView.as_view()

class CustomerView(TemplateView):
    template_name="polls/customer.html"
    redirect_authenticated_user = True 

customer = CustomerView.as_view()


#def number(request, input_num):
   # return render(request, 'polls/wash.html')